* Keep icon folder and calculator.exe in the same directory
* I've included the code to check out in the code folder